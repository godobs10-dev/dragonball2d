'use strict';
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const crypto = require('crypto');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' },
  pingTimeout: 10000,
  pingInterval: 5000,
});

const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ── ROOM STATE ──────────────────────────────────────────────────
// rooms: { [code]: Room }
// Room: { code, players: [socket.id, socket.id|null], chars: [charKey|null, charKey|null], state: 'waiting'|'selecting'|'fighting'|'gameover', spectators: Set }
const rooms = new Map();
// socketToRoom: { [socketId]: roomCode }
const socketToRoom = new Map();

function genCode() {
  return crypto.randomBytes(3).toString('hex').toUpperCase();
}

function getRoom(code) { return rooms.get(code); }

function getRoomBySocket(id) {
  const code = socketToRoom.get(id);
  return code ? getRoom(code) : null;
}

function cleanRoom(code) {
  const room = rooms.get(code);
  if (!room) return;
  room.players.forEach(id => { if (id) socketToRoom.delete(id); });
  room.spectators.forEach(id => socketToRoom.delete(id));
  rooms.delete(code);
}

// ── SOCKET EVENTS ───────────────────────────────────────────────
io.on('connection', (socket) => {
  // ─ Create Room ─
  socket.on('create_room', ({ charKey }) => {
    const code = genCode();
    const room = {
      code,
      players: [socket.id, null],
      chars: [charKey || null, null],
      state: 'waiting',
      spectators: new Set(),
      round: 1,
      wins: [0, 0],
    };
    rooms.set(code, room);
    socketToRoom.set(socket.id, code);
    socket.join(code);
    socket.emit('room_created', { code, playerIndex: 0 });
    console.log(`Room ${code} created by ${socket.id}`);
  });

  // ─ Join Room ─
  socket.on('join_room', ({ code, charKey }) => {
    code = code.toUpperCase().trim();
    const room = getRoom(code);
    if (!room) { socket.emit('error', { msg: 'Sala não encontrada.' }); return; }
    if (room.state === 'fighting') { socket.emit('error', { msg: 'Partida em andamento.' }); return; }

    if (room.players[1] === null) {
      // Join as P2
      room.players[1] = socket.id;
      room.chars[1] = charKey || null;
      socketToRoom.set(socket.id, code);
      socket.join(code);
      socket.emit('room_joined', { code, playerIndex: 1, p1Char: room.chars[0] });
      // Notify P1
      io.to(room.players[0]).emit('opponent_joined', { charKey: charKey || null });
      console.log(`Room ${code}: P2 joined`);

      if (room.chars[0] && room.chars[1]) {
        startFight(room);
      }
    } else {
      // Spectate
      room.spectators.add(socket.id);
      socketToRoom.set(socket.id, code);
      socket.join(code);
      socket.emit('spectating', { code, chars: room.chars, state: room.state });
    }
  });

  // ─ Char selected ─
  socket.on('char_selected', ({ charKey }) => {
    const room = getRoomBySocket(socket.id);
    if (!room) return;
    const idx = room.players.indexOf(socket.id);
    if (idx === -1) return;
    room.chars[idx] = charKey;
    // Notify opponent
    const oppId = room.players[1 - idx];
    if (oppId) io.to(oppId).emit('opponent_char', { charKey });
    // If both selected → start
    if (room.chars[0] && room.chars[1]) startFight(room);
  });

  // ─ Input relay (authoritative input → rebroadcast to opponent) ─
  socket.on('input', ({ frame, input }) => {
    const room = getRoomBySocket(socket.id);
    if (!room || room.state !== 'fighting') return;
    const idx = room.players.indexOf(socket.id);
    if (idx === -1) return;
    const oppId = room.players[1 - idx];
    if (oppId) io.to(oppId).emit('opponent_input', { frame, input, playerIndex: idx });
  });

  // ─ Game event (KO, round end) broadcast ─
  socket.on('game_event', (data) => {
    const room = getRoomBySocket(socket.id);
    if (!room) return;
    io.to(room.code).emit('game_event', data);
    if (data.type === 'game_over') room.state = 'gameover';
  });

  // ─ Rematch ─
  socket.on('rematch', () => {
    const room = getRoomBySocket(socket.id);
    if (!room) return;
    const idx = room.players.indexOf(socket.id);
    if (idx === -1) return;
    if (!room.rematchVotes) room.rematchVotes = new Set();
    room.rematchVotes.add(idx);
    if (room.rematchVotes.size === 2) {
      room.rematchVotes.clear();
      room.state = 'fighting';
      room.wins = [0, 0];
      io.to(room.code).emit('rematch_start', { chars: room.chars });
    } else {
      const oppId = room.players[1 - idx];
      if (oppId) io.to(oppId).emit('rematch_requested');
    }
  });

  // ─ Ping (latency) ─
  socket.on('ping_check', (ts) => { socket.emit('pong_check', ts); });

  // ─ Disconnect ─
  socket.on('disconnect', () => {
    const room = getRoomBySocket(socket.id);
    if (!room) return;
    const idx = room.players.indexOf(socket.id);
    if (idx !== -1) {
      room.players[idx] = null;
      room.chars[idx] = null;
      io.to(room.code).emit('opponent_disconnected', { playerIndex: idx });
      // If both gone, clean up after delay
      if (!room.players[0] && !room.players[1]) {
        setTimeout(() => cleanRoom(room.code), 30000);
      }
    } else {
      room.spectators.delete(socket.id);
    }
    socketToRoom.delete(socket.id);
    console.log(`${socket.id} left room ${room.code}`);
  });
});

function startFight(room) {
  room.state = 'fighting';
  io.to(room.code).emit('fight_start', {
    chars: room.chars,
    playerIndices: { [room.players[0]]: 0, [room.players[1]]: 1 },
  });
  console.log(`Room ${room.code}: FIGHT START — ${room.chars[0]} vs ${room.chars[1]}`);
}

// ── Stats endpoint ──────────────────────────────────────────────
app.get('/api/rooms', (req, res) => {
  res.json({ active: rooms.size, players: [...socketToRoom.keys()].length });
});

server.listen(PORT, () => {
  console.log(`Dragon Fury Online running on port ${PORT}`);
});
