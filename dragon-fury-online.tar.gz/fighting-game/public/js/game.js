'use strict';
// ═══════════════════════════════════════════════════════════════
//  DRAGON FURY — 2D Fighting Game Engine
//  Characters: Kairu · Vegara · Zurak · Miroku
// ═══════════════════════════════════════════════════════════════

// ── AUDIO ENGINE ────────────────────────────────────────────────
const AudioEngine = (() => {
  let ctx = null;
  function init() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
  }
  function resume() { if (ctx && ctx.state === 'suspended') ctx.resume(); }

  function playTone(freq, type, dur, vol=0.3, attack=0.01, decay=0.1) {
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type = type; osc.frequency.value = freq;
    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(vol, now + attack);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);
    osc.start(now); osc.stop(now + dur + 0.05);
  }

  function noise(dur, vol=0.2) {
    if (!ctx) return;
    const buf = ctx.createBuffer(1, ctx.sampleRate * dur, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    src.buffer = buf;
    filter.type = 'bandpass'; filter.frequency.value = 800;
    src.connect(filter); filter.connect(gain); gain.connect(ctx.destination);
    const now = ctx.currentTime;
    gain.gain.setValueAtTime(vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);
    src.start(now);
  }

  const sounds = {
    hit_light: () => { playTone(180, 'square', 0.12, 0.4); noise(0.08, 0.15); },
    hit_heavy: () => { playTone(100, 'square', 0.2, 0.5); noise(0.15, 0.3); playTone(60, 'sawtooth', 0.15, 0.3); },
    block:     () => { playTone(400, 'square', 0.08, 0.3); playTone(300, 'square', 0.08, 0.2); },
    ki_blast:  () => { playTone(600, 'sine', 0.3, 0.4); playTone(400, 'sine', 0.3, 0.2); },
    ultimate:  () => {
      [200,300,500,800,1200].forEach((f,i) => setTimeout(() => playTone(f,'sine',0.4,0.3+i*0.05),i*60));
      noise(0.5, 0.5);
    },
    jump:      () => { playTone(300, 'sine', 0.15, 0.2); },
    land:      () => { noise(0.1, 0.15); playTone(80, 'square', 0.1, 0.2); },
    round_start: () => {
      [200,400,600].forEach((f,i) => setTimeout(() => playTone(f,'square',0.3,0.4),i*100));
    },
    ko:        () => {
      playTone(100,'sawtooth',0.6,0.6); noise(0.4,0.4);
      setTimeout(() => playTone(60,'square',0.8,0.5), 200);
    },
    menu_sel:  () => { playTone(500,'sine',0.1,0.2); },
  };

  return { init, resume, play: (name) => { resume(); if (sounds[name]) sounds[name](); } };
})();

// ── PARTICLES ───────────────────────────────────────────────────
class ParticleSystem {
  constructor() { this.particles = []; }

  emit(x, y, type, count=8) {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 6 + 2;
      let p = {
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1.0,
        decay: Math.random() * 0.04 + 0.03,
        size: Math.random() * 8 + 3,
        type,
      };
      if (type === 'hit')    { p.color = `hsl(${30+Math.random()*30},100%,70%)`; p.size = Math.random()*6+2; }
      if (type === 'heavy')  { p.color = `hsl(${200+Math.random()*60},100%,70%)`; p.size = Math.random()*10+4; p.decay=0.025; }
      if (type === 'ki')     { p.color = `hsl(${180+Math.random()*60},100%,80%)`; p.size = Math.random()*5+2; p.decay=0.04; }
      if (type === 'blast')  { p.color = `hsl(${50+Math.random()*30},100%,70%)`; p.size = Math.random()*8+4; p.decay=0.03; speed*=1.5; }
      if (type === 'ultimate') { p.color = `hsl(${Math.random()*360},100%,70%)`; p.size = Math.random()*15+5; p.decay=0.02; }
      if (type === 'block')  { p.color = `hsl(60,100%,80%)`; p.size = Math.random()*5+2; p.vx*=0.5; }
      if (type === 'trail')  { p.color = `hsl(${200+Math.random()*40},100%,70%)`; p.size = Math.random()*4+1; p.decay=0.08; }
      p.vy -= 1;
      this.particles.push(p);
    }
  }

  emitBeam(x, y, dir, color, count=12) {
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x, y,
        vx: dir * (Math.random() * 15 + 10),
        vy: (Math.random() - 0.5) * 4,
        life: 1.0, decay: 0.06,
        size: Math.random() * 8 + 2,
        color,
        type: 'beam'
      });
    }
  }

  update() {
    this.particles = this.particles.filter(p => {
      p.x += p.vx; p.y += p.vy;
      p.vy += 0.3; // gravity
      p.vx *= 0.92; p.vy *= 0.95;
      p.life -= p.decay;
      p.size *= 0.97;
      return p.life > 0;
    });
  }

  draw(ctx) {
    this.particles.forEach(p => {
      ctx.save();
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.shadowBlur = 10;
      ctx.shadowColor = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, Math.max(0.1, p.size), 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
  }
}

// ── CHARACTER DEFINITIONS ────────────────────────────────────────
const CHARACTERS = {
  kairu: {
    name: 'KAIRU',
    title: 'O Guerreiro do Ki',
    color: '#00cfff',
    auraColor: 'rgba(0,207,255,',
    hairColor: '#1a1a4e',
    skinColor: '#f4c590',
    armorColor: '#003366',
    stats: { power: 70, speed: 75, defense: 70, ki: 80 },
    maxHP: 1000,
    walkSpeed: 4.5,
    jumpPower: -18,
    weight: 1.0,
    moves: {
      light:  { damage: 55,  startup: 4,  active: 3,  recovery: 8,  knockback: 4,  kiGain: 8,  range: 70 },
      heavy:  { damage: 110, startup: 8,  active: 5,  recovery: 14, knockback: 10, kiGain: 15, range: 80 },
      sp1:    { damage: 85,  startup: 10, active: 20, recovery: 12, knockback: 8,  kiCost: 20, range: 400, type: 'projectile', name: 'Feixe de Ki' },
      sp2:    { damage: 95,  startup: 6,  active: 6,  recovery: 16, knockback: 12, kiCost: 25, range: 110, type: 'rush', name: 'Golpe Relâmpago' },
      ultimate: { damage: 280, startup: 20, active: 30, recovery: 30, knockback: 25, kiCost: 100, range: 500, type: 'ultimate', name: 'EXPLOSÃO FINAL' },
    }
  },
  vegara: {
    name: 'VEGARA',
    title: 'Príncipe das Chamas',
    color: '#ff4444',
    auraColor: 'rgba(255,100,0,',
    hairColor: '#111',
    skinColor: '#f4c590',
    armorColor: '#660000',
    stats: { power: 90, speed: 65, defense: 60, ki: 70 },
    maxHP: 950,
    walkSpeed: 4.0,
    jumpPower: -16,
    weight: 1.1,
    moves: {
      light:  { damage: 65,  startup: 5,  active: 3,  recovery: 8,  knockback: 5,  kiGain: 10, range: 72 },
      heavy:  { damage: 135, startup: 9,  active: 6,  recovery: 16, knockback: 14, kiGain: 18, range: 85 },
      sp1:    { damage: 75,  startup: 8,  active: 25, recovery: 10, knockback: 6,  kiCost: 20, range: 380, type: 'multiprojectile', name: 'Chuva de Ki' },
      sp2:    { damage: 115, startup: 5,  active: 8,  recovery: 18, knockback: 15, kiCost: 30, range: 120, type: 'rush', name: 'Investida Final' },
      ultimate: { damage: 320, startup: 18, active: 35, recovery: 35, knockback: 30, kiCost: 100, range: 500, type: 'ultimate', name: 'CANHÃO FINAL' },
    }
  },
  zurak: {
    name: 'ZURAK',
    title: 'O Guardião Verde',
    color: '#00ff88',
    auraColor: 'rgba(0,200,100,',
    hairColor: '#222',
    skinColor: '#5a9e6e',
    armorColor: '#1a3a1a',
    stats: { power: 65, speed: 55, defense: 90, ki: 65 },
    maxHP: 1150,
    walkSpeed: 3.5,
    jumpPower: -15,
    weight: 1.3,
    moves: {
      light:  { damage: 50,  startup: 6,  active: 4,  recovery: 7,  knockback: 3,  kiGain: 7,  range: 90 },
      heavy:  { damage: 100, startup: 10, active: 6,  recovery: 12, knockback: 8,  kiGain: 12, range: 100 },
      sp1:    { damage: 60,  startup: 12, active: 15, recovery: 10, knockback: 5,  kiCost: 15, range: 300, type: 'ring', name: 'Anel de Energia' },
      sp2:    { damage: 0,   startup: 5,  active: 1,  recovery: 20, knockback: 0,  kiCost: 20, range: 0,   type: 'heal', name: 'Regenerar' },
      ultimate: { damage: 250, startup: 22, active: 40, recovery: 25, knockback: 20, kiCost: 100, range: 450, type: 'ultimate', name: 'TEMPESTADE VERDE' },
    }
  },
  miroku: {
    name: 'MIROKU',
    title: 'Sombra da Velocidade',
    color: '#cc44ff',
    auraColor: 'rgba(180,0,255,',
    hairColor: '#fff',
    skinColor: '#d4b896',
    armorColor: '#2a0044',
    stats: { power: 60, speed: 95, defense: 55, ki: 75 },
    maxHP: 900,
    walkSpeed: 6.0,
    jumpPower: -20,
    weight: 0.85,
    moves: {
      light:  { damage: 45,  startup: 2,  active: 2,  recovery: 5,  knockback: 3,  kiGain: 7,  range: 65 },
      heavy:  { damage: 90,  startup: 6,  active: 4,  recovery: 12, knockback: 8,  kiGain: 12, range: 75 },
      sp1:    { damage: 70,  startup: 3,  active: 8,  recovery: 15, knockback: 5,  kiCost: 20, range: 200, type: 'teleport', name: 'Golpe Fantasma' },
      sp2:    { damage: 55,  startup: 4,  active: 15, recovery: 10, knockback: 4,  kiCost: 15, range: 300, type: 'multiHit', name: 'Rafaga de Sombras' },
      ultimate: { damage: 290, startup: 15, active: 50, recovery: 20, knockback: 22, kiCost: 100, range: 500, type: 'ultimate', name: 'CORTE DIMENSIONAL' },
    }
  }
};

// ── FIGHTER CLASS ────────────────────────────────────────────────
class Fighter {
  constructor(charKey, x, facingRight, playerIndex) {
    const def = CHARACTERS[charKey];
    this.charKey = charKey;
    this.def = def;
    this.playerIndex = playerIndex;
    this.facingRight = facingRight;

    this.x = x;
    this.y = 0;
    this.vx = 0;
    this.vy = 0;
    this.w = 60;
    this.h = 110;

    this.hp = def.maxHP;
    this.maxHP = def.maxHP;
    this.ki = 0;
    this.maxKi = 100;

    this.state = 'idle'; // idle|walk|jump|crouch|attack|hurt|block|dead|special
    this.stateTimer = 0;
    this.onGround = false;
    this.jumpCount = 0;
    this.maxJumps = 2;

    this.attackData = null;
    this.attackHitFrame = false;
    this.hitCooldown = 0;

    this.combo = 0;
    this.comboTimer = 0;
    this.blockTimer = 0;

    this.invincible = 0;
    this.hitstun = 0;
    this.knockback = 0;

    this.animFrame = 0;
    this.animTimer = 0;

    this.projectiles = [];
    this.effects = [];

    this.trailPositions = [];
    this.isHealing = false;
  }

  get cx() { return this.x + this.w / 2; }
  get cy() { return this.y + this.h / 2; }

  applyInput(input, ground, cW) {
    if (this.state === 'dead' || this.hitstun > 0) return;

    const def = this.def;
    const onGround = this.onGround;

    // Block
    if (input.block && onGround && this.state !== 'attack' && this.state !== 'special') {
      this.state = 'block';
      this.blockTimer = 3;
      this.vx = 0;
      return;
    }
    if (this.state === 'block' && !input.block) {
      this.state = 'idle';
    }

    // Attacks take priority over movement
    if (this.state === 'attack' || this.state === 'special') return;

    // Movement
    if (input.left) {
      this.vx = -def.walkSpeed;
      if (onGround) this.state = 'walk';
      this.facingRight = false;
    } else if (input.right) {
      this.vx = def.walkSpeed;
      if (onGround) this.state = 'walk';
      this.facingRight = true;
    } else {
      this.vx *= 0.7;
      if (onGround && this.state === 'walk') this.state = 'idle';
    }

    if (input.down && onGround) {
      this.state = 'crouch';
      this.vx = 0;
    } else if (this.state === 'crouch' && !input.down) {
      this.state = 'idle';
    }

    // Jump
    if (input.up && this.jumpCount < this.maxJumps) {
      this.vy = def.jumpPower;
      this.jumpCount++;
      this.state = 'jump';
      AudioEngine.play('jump');
      if (this.jumpCount > 1) {
        // double jump trail
        this.effects.push({ type: 'ring', x: this.cx, y: this.cy, life: 1, color: this.def.color });
      }
    }

    // Attacks
    if (input.light)    this.startAttack('light');
    if (input.heavy)    this.startAttack('heavy');
    if (input.sp1)      this.startSpecial('sp1');
    if (input.sp2)      this.startSpecial('sp2');
    if (input.ultimate) this.startSpecial('ultimate');
  }

  startAttack(type) {
    const move = this.def.moves[type];
    if (!move) return;
    this.state = 'attack';
    this.stateTimer = move.startup + move.active + move.recovery;
    this.attackData = { ...move, type, timer: move.startup + move.active + move.recovery, hitLanded: false };
    this.attackHitFrame = false;
  }

  startSpecial(type) {
    const move = this.def.moves[type];
    if (!move) return;
    if (move.kiCost && this.ki < move.kiCost) return;

    if (move.type === 'heal') {
      this.ki -= move.kiCost || 0;
      const healAmt = this.maxHP * 0.12;
      this.hp = Math.min(this.maxHP, this.hp + healAmt);
      this.isHealing = true;
      this.effects.push({ type: 'heal', life: 1.5, x: this.cx, y: this.y });
      setTimeout(() => { this.isHealing = false; }, 800);
      AudioEngine.play('ki_blast');
      return;
    }

    if (move.kiCost) this.ki -= move.kiCost;
    this.state = 'special';
    this.stateTimer = move.startup + move.active + move.recovery;
    this.attackData = { ...move, type, timer: move.startup + move.active + move.recovery, hitLanded: false };
    this.attackHitFrame = false;

    if (type === 'ultimate') {
      AudioEngine.play('ultimate');
      this.invincible = move.startup + 5;
    }
  }

  getHitbox() {
    if (!this.attackData) return null;
    const a = this.attackData;
    const elapsed = (a.startup + a.active + a.recovery) - this.stateTimer;
    if (elapsed < a.startup || elapsed >= a.startup + a.active) return null;
    if (a.hitLanded && a.type !== 'sp1' && a.type !== 'sp2' && a.type !== 'ultimate') return null;

    const dir = this.facingRight ? 1 : -1;
    const range = a.range || 80;

    if (a.type === 'projectile' || a.type === 'multiprojectile' || a.type === 'ring') return null;
    if (a.type === 'teleport') {
      return { x: this.x + (this.facingRight ? this.w : -range), y: this.y, w: range, h: this.h };
    }
    if (a.type === 'ultimate') {
      return { x: this.facingRight ? this.x + this.w : this.x - 300, y: this.y - 50, w: 300, h: this.h + 100 };
    }

    return {
      x: this.facingRight ? this.x + this.w * 0.5 : this.x - range + this.w * 0.5,
      y: this.y + this.h * 0.1,
      w: range,
      h: this.h * 0.8
    };
  }

  spawnProjectile(canvas) {
    const a = this.attackData;
    if (!a) return;
    const dir = this.facingRight ? 1 : -1;

    if (a.type === 'projectile') {
      this.projectiles.push({
        x: this.cx + dir * 30, y: this.cy - 10,
        vx: dir * 12, vy: 0,
        life: 1.0, speed: 12,
        damage: a.damage, color: this.def.color,
        type: 'beam', w: 20, h: 10,
        trail: []
      });
      AudioEngine.play('ki_blast');
    } else if (a.type === 'multiprojectile') {
      for (let i = -1; i <= 1; i++) {
        this.projectiles.push({
          x: this.cx + dir * 30, y: this.cy - 10,
          vx: dir * 10, vy: i * 3,
          life: 1.0, damage: Math.floor(a.damage * 0.6), color: this.def.color,
          type: 'orb', w: 12, h: 12, trail: []
        });
      }
      AudioEngine.play('ki_blast');
    } else if (a.type === 'ring') {
      this.projectiles.push({
        x: this.cx + dir * 20, y: this.cy,
        vx: dir * 8, vy: 0,
        life: 1.0, damage: a.damage, color: this.def.color,
        type: 'ring_proj', w: 25, h: 25, trail: []
      });
      AudioEngine.play('ki_blast');
    } else if (a.type === 'ultimate') {
      AudioEngine.play('ultimate');
    }
  }

  update(ground, cW, particles) {
    // Gravity
    if (!this.onGround) {
      this.vy += 0.9 * this.def.weight;
    }

    this.x += this.vx;
    this.y += this.vy;

    // Floor collision
    if (this.y + this.h >= ground) {
      this.y = ground - this.h;
      this.vy = 0;
      if (!this.onGround) {
        AudioEngine.play('land');
        particles.emit(this.cx, this.y + this.h, 'trail', 4);
      }
      this.onGround = true;
      this.jumpCount = 0;
      if (this.state === 'jump') this.state = 'idle';
    } else {
      this.onGround = false;
    }

    // Wall bounds
    this.x = Math.max(10, Math.min(cW - this.w - 10, this.x));

    // State timer
    if (this.stateTimer > 0) {
      this.stateTimer--;
      if (this.attackData) {
        this.attackData.timer--;
        const elapsed = (this.attackData.startup + this.attackData.active + this.attackData.recovery) - this.stateTimer;
        // Spawn projectile at right frame
        if (elapsed === this.attackData.startup && (
          this.attackData.type === 'projectile' ||
          this.attackData.type === 'multiprojectile' ||
          this.attackData.type === 'ring'
        )) {
          this.spawnProjectile();
        }
      }
      if (this.stateTimer <= 0 && this.state !== 'dead') {
        this.state = this.onGround ? 'idle' : 'jump';
        this.attackData = null;
      }
    }

    // Hitstun
    if (this.hitstun > 0) { this.hitstun--; if (this.hitstun === 0 && this.state === 'hurt') this.state = 'idle'; }
    if (this.invincible > 0) this.invincible--;
    if (this.blockTimer > 0) this.blockTimer--;
    if (this.hitCooldown > 0) this.hitCooldown--;

    // Combo timer
    if (this.comboTimer > 0) { this.comboTimer--; }
    else { this.combo = 0; }

    // Ki regeneration
    if (this.state !== 'special' && this.state !== 'ultimate') {
      this.ki = Math.min(this.maxKi, this.ki + 0.05);
    }

    // Animation
    this.animTimer++;
    if (this.animTimer > 8) { this.animTimer = 0; this.animFrame++; }

    // Update projectiles
    this.projectiles = this.projectiles.filter(p => {
      p.trail.push({ x: p.x, y: p.y });
      if (p.trail.length > 8) p.trail.shift();
      p.x += p.vx; p.y += p.vy;
      p.life -= 0.008;
      if (p.x < 0 || p.x > cW) p.life = 0;
      return p.life > 0;
    });

    // Trail for speed char
    if (this.charKey === 'miroku' && (this.state === 'walk' || this.state === 'jump')) {
      this.trailPositions.push({ x: this.x, y: this.y, opacity: 0.4 });
      if (this.trailPositions.length > 5) this.trailPositions.shift();
    }
    this.trailPositions.forEach(t => { t.opacity -= 0.08; });
    this.trailPositions = this.trailPositions.filter(t => t.opacity > 0);

    // Healing particles
    if (this.isHealing) {
      particles.emit(this.cx, this.cy, 'ki', 3);
    }
  }

  receiveHit(move, attacker, particles) {
    if (this.invincible > 0) return false;
    if (this.hitCooldown > 0) return false;

    let dmg = move.damage;
    let isBlocking = this.state === 'block';

    if (isBlocking) {
      dmg = Math.floor(dmg * 0.15);
      AudioEngine.play('block');
      particles.emit(this.cx, this.cy, 'block', 10);
    } else {
      const hitType = move.damage > 100 ? 'hit_heavy' : 'hit_light';
      AudioEngine.play(hitType);

      const pType = move.damage > 100 ? 'heavy' : 'hit';
      particles.emit(this.cx, this.cy, pType, move.damage > 100 ? 15 : 8);

      this.hitstun = isBlocking ? 4 : Math.floor(move.startup * 2 + 10);
      this.state = 'hurt';
      this.vx = (attacker.facingRight ? 1 : -1) * (move.knockback || 5);
      this.vy = -5;
      this.ki = Math.min(this.maxKi, this.ki + (move.kiGain || 10) * 0.5);
    }

    this.hp = Math.max(0, this.hp - dmg);
    this.hitCooldown = 15;
    attacker.ki = Math.min(attacker.maxKi, attacker.ki + (move.kiGain || 8));
    attacker.combo++;
    attacker.comboTimer = 60;

    return true;
  }

  draw(ctx, cW, cH) {
    const def = this.def;
    const dir = this.facingRight ? 1 : -1;
    const t = this.animFrame;

    // Draw trail (Miroku)
    this.trailPositions.forEach(tr => {
      ctx.save();
      ctx.globalAlpha = tr.opacity;
      this._drawBody(ctx, tr.x, tr.y, def.color, true);
      ctx.restore();
    });

    ctx.save();
    ctx.translate(this.x + this.w / 2, this.y + this.h);
    ctx.scale(this.facingRight ? 1 : -1, 1);

    // Hurt flash
    if (this.hitstun > 0 && Math.floor(this.hitstun / 2) % 2 === 0) {
      ctx.filter = 'brightness(3)';
    }

    // Aura
    if (this.state === 'special' || this.isHealing || this.invincible > 0) {
      this._drawAura(ctx, def.auraColor, t);
    }

    // Body
    this._drawBodyFromOrigin(ctx, def, t);

    // Attack effect
    if (this.state === 'attack' || this.state === 'special') {
      this._drawAttackEffect(ctx, def, t);
    }

    ctx.restore();

    // Projectiles
    this.projectiles.forEach(p => this._drawProjectile(ctx, p));

    // Effects
    this.effects = this.effects.filter(e => {
      e.life -= 0.04;
      if (e.type === 'ring') {
        ctx.save();
        ctx.strokeStyle = def.color;
        ctx.lineWidth = 3;
        ctx.globalAlpha = e.life;
        ctx.shadowBlur = 10;
        ctx.shadowColor = def.color;
        ctx.beginPath();
        ctx.arc(e.x, e.y, (1 - e.life) * 60 + 20, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
      if (e.type === 'heal') {
        ctx.save();
        ctx.fillStyle = '#00ff88';
        ctx.font = `bold ${Math.floor(16 + (1-e.life)*10)}px Orbitron`;
        ctx.globalAlpha = e.life;
        ctx.fillText('+HP', e.x - 15, e.y - (1-e.life)*40);
        ctx.restore();
      }
      return e.life > 0;
    });

    // Shadow on ground
    ctx.save();
    ctx.globalAlpha = 0.3;
    ctx.fillStyle = '#000';
    ctx.scale(1, 0.3);
    ctx.beginPath();
    ctx.ellipse(this.cx, (this.y + this.h) / 0.3, this.w * 0.4, 15, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  _drawAura(ctx, auraColor, t) {
    const pulse = Math.sin(t * 0.3) * 10 + 20;
    const grad = ctx.createRadialGradient(0, -55, 10, 0, -55, 60 + pulse);
    grad.addColorStop(0, auraColor + '0.6)');
    grad.addColorStop(0.5, auraColor + '0.2)');
    grad.addColorStop(1, auraColor + '0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(0, -55, 60 + pulse * 0.5, 80 + pulse, 0, 0, Math.PI * 2);
    ctx.fill();

    // Aura particles arcs
    for (let i = 0; i < 4; i++) {
      const angle = (t * 0.15 + i * Math.PI / 2);
      const r = 40 + Math.sin(t * 0.2 + i) * 10;
      ctx.save();
      ctx.strokeStyle = auraColor + '0.5)';
      ctx.lineWidth = 2;
      ctx.shadowBlur = 8;
      ctx.shadowColor = auraColor + '1)';
      ctx.beginPath();
      ctx.arc(0, -55, r, angle, angle + Math.PI * 0.6);
      ctx.stroke();
      ctx.restore();
    }
  }

  _drawBodyFromOrigin(ctx, def, t) {
    // Origin is at feet-center (bottom of character)
    const bob = this.state === 'idle' ? Math.sin(t * 0.2) * 2 : 0;
    const jumpLean = !this.onGround ? (this.vy < 0 ? -15 : 15) : 0;
    const attackLean = (this.state === 'attack' || this.state === 'special') ? 20 : 0;

    ctx.save();
    ctx.translate(0, bob);

    // Legs
    const legSwing = this.state === 'walk' ? Math.sin(t * 0.4) * 15 : 0;
    // Left leg
    ctx.save();
    ctx.rotate((legSwing - jumpLean * 0.3) * Math.PI / 180);
    this._drawLimb(ctx, def.armorColor, 0, -40, 8, 40);
    ctx.restore();
    // Right leg
    ctx.save();
    ctx.rotate((-legSwing - jumpLean * 0.3) * Math.PI / 180);
    this._drawLimb(ctx, def.armorColor, 0, -40, 8, 40);
    ctx.restore();

    // Torso
    ctx.fillStyle = def.armorColor;
    ctx.shadowBlur = 5; ctx.shadowColor = def.color;
    ctx.fillRect(-18, -100, 36, 55);
    // Chest detail
    ctx.fillStyle = def.color;
    ctx.globalAlpha = 0.4;
    ctx.fillRect(-10, -95, 20, 15);
    ctx.globalAlpha = 1;

    // Arms
    const armSwing = this.state === 'walk' ? Math.sin(t * 0.4 + Math.PI) * 20 : 0;
    const attackArm = (this.state === 'attack' || this.state === 'special') ? 50 : 0;

    // Left arm
    ctx.save();
    ctx.translate(-18, -90);
    ctx.rotate((armSwing + jumpLean * 0.5) * Math.PI / 180);
    this._drawLimb(ctx, def.skinColor, 0, 0, 7, 32);
    ctx.restore();

    // Right arm (attack arm)
    ctx.save();
    ctx.translate(18, -90);
    ctx.rotate((-armSwing + attackLean + jumpLean * 0.5) * Math.PI / 180);
    this._drawLimb(ctx, def.skinColor, 0, 0, 7, 32);
    // Fist
    ctx.fillStyle = def.skinColor;
    ctx.beginPath();
    ctx.arc(0, 32, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Neck
    ctx.fillStyle = def.skinColor;
    ctx.fillRect(-6, -115, 12, 20);

    // Head
    ctx.save();
    ctx.translate(0, -130);
    // Face
    ctx.fillStyle = def.skinColor;
    ctx.shadowBlur = 0;
    ctx.beginPath();
    ctx.ellipse(0, 0, 18, 22, 0, 0, Math.PI * 2);
    ctx.fill();

    // Hair
    ctx.fillStyle = def.hairColor;
    this._drawHair(ctx, def.hairColor, this.charKey, t);

    // Eyes
    const eyeGlow = (this.state === 'special' || this.invincible > 0) ? def.color : '#fff';
    ctx.fillStyle = eyeGlow;
    ctx.shadowBlur = this.state === 'special' ? 10 : 0;
    ctx.shadowColor = eyeGlow;
    ctx.beginPath(); ctx.ellipse(-6, -4, 4, 5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(6, -4, 4, 5, 0, 0, Math.PI * 2); ctx.fill();
    // Pupils
    ctx.fillStyle = '#000';
    ctx.shadowBlur = 0;
    ctx.beginPath(); ctx.arc(-6, -3, 2, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(6, -3, 2, 0, Math.PI * 2); ctx.fill();

    ctx.restore();
    ctx.restore();
  }

  _drawHair(ctx, color, charKey, t) {
    ctx.fillStyle = color;
    if (charKey === 'kairu') {
      // Spiky hair pointing up
      for (let i = -2; i <= 2; i++) {
        ctx.beginPath();
        ctx.moveTo(i * 7 - 3, -18);
        ctx.lineTo(i * 7, -18 - Math.abs(i) * 2 - 22 + (i%2===0?5:0));
        ctx.lineTo(i * 7 + 3, -18);
        ctx.fill();
      }
    } else if (charKey === 'vegara') {
      // Tall flame hair
      ctx.beginPath();
      ctx.moveTo(-15, -15); ctx.lineTo(0, -55); ctx.lineTo(15, -15);
      ctx.fill();
      ctx.fillStyle = '#ff4400';
      ctx.globalAlpha = 0.6;
      ctx.beginPath();
      ctx.moveTo(-10, -18); ctx.lineTo(0, -45 + Math.sin(t*0.3)*3); ctx.lineTo(10, -18);
      ctx.fill();
      ctx.globalAlpha = 1;
    } else if (charKey === 'zurak') {
      // Smooth dark hair
      ctx.beginPath();
      ctx.ellipse(0, -18, 18, 10, 0, Math.PI, 0);
      ctx.fill();
      // Antennae
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-5,-22); ctx.lineTo(-10,-38); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(5,-22); ctx.lineTo(10,-38); ctx.stroke();
    } else if (charKey === 'miroku') {
      // White long hair flowing
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.moveTo(-18,-5); ctx.quadraticCurveTo(-30+Math.sin(t*0.2)*5, 20, -20, 35);
      ctx.lineTo(-16, 35); ctx.quadraticCurveTo(-24, 15, -13, -5);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(0, -18, 18, 10, 0, Math.PI, 0);
      ctx.fill();
    }
  }

  _drawLimb(ctx, color, x, y, r, len) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.rect(x - r, y, r * 2, len);
    ctx.fill();
  }

  _drawAttackEffect(ctx, def, t) {
    const a = this.attackData;
    if (!a) return;
    ctx.save();
    ctx.translate(28, -80);

    if (a.type === 'light') {
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.globalAlpha = 0.7;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(60, -20); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, 10); ctx.lineTo(70, 0); ctx.stroke();
    } else if (a.type === 'heavy') {
      ctx.strokeStyle = def.color;
      ctx.lineWidth = 4;
      ctx.shadowBlur = 15; ctx.shadowColor = def.color;
      for (let i = 0; i < 3; i++) {
        ctx.globalAlpha = 0.8 - i * 0.2;
        ctx.beginPath(); ctx.arc(10 + i * 20, -10, 15 + i * 5, -Math.PI/4, Math.PI/4); ctx.stroke();
      }
    } else if (a.type === 'ultimate') {
      const pulse = Math.sin(t * 0.5) * 10;
      ctx.fillStyle = def.color;
      ctx.globalAlpha = 0.6;
      ctx.shadowBlur = 30; ctx.shadowColor = def.color;
      ctx.beginPath();
      ctx.arc(50 + pulse, 0, 30 + pulse, 0, Math.PI * 2);
      ctx.fill();
      // Rays
      for (let i = 0; i < 8; i++) {
        const ang = (i / 8) * Math.PI * 2 + t * 0.1;
        ctx.strokeStyle = def.color;
        ctx.lineWidth = 3;
        ctx.globalAlpha = 0.5;
        ctx.beginPath();
        ctx.moveTo(50 + Math.cos(ang)*30, Math.sin(ang)*30);
        ctx.lineTo(50 + Math.cos(ang)*80, Math.sin(ang)*80);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  _drawProjectile(ctx, p) {
    // Trail
    p.trail.forEach((tr, i) => {
      ctx.save();
      ctx.globalAlpha = (i / p.trail.length) * p.life * 0.4;
      ctx.fillStyle = p.color;
      ctx.shadowBlur = 5;
      ctx.shadowColor = p.color;
      ctx.beginPath();
      const s = p.w * 0.4 * (i / p.trail.length);
      ctx.arc(tr.x, tr.y, Math.max(1, s), 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });

    ctx.save();
    ctx.globalAlpha = p.life;
    ctx.fillStyle = p.color;
    ctx.shadowBlur = 20;
    ctx.shadowColor = p.color;

    if (p.type === 'beam') {
      ctx.fillRect(p.x - p.w/2, p.y - p.h/2, p.w, p.h);
      ctx.fillStyle = '#fff';
      ctx.globalAlpha = p.life * 0.5;
      ctx.fillRect(p.x - p.w/2 + 2, p.y - 2, p.w - 4, 4);
    } else if (p.type === 'orb') {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.w / 2, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.type === 'ring_proj') {
      ctx.strokeStyle = p.color;
      ctx.lineWidth = 4;
      ctx.fillStyle = 'transparent';
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.w / 2, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();
  }

  _drawBody(ctx, x, y, color, ghost=false) {
    // Simple silhouette for trail
    ctx.fillStyle = color;
    ctx.fillRect(x + 10, y, 40, 110);
  }
}

// ── AI CONTROLLER ────────────────────────────────────────────────
class AIController {
  constructor(fighter, opponent) {
    this.fighter = fighter;
    this.opponent = opponent;
    this.actionTimer = 0;
    this.currentAction = null;
    this.difficulty = 0.75; // 0–1
    this.reactionDelay = Math.floor(10 + (1 - this.difficulty) * 20);
    this.reactionTimer = 0;
    this.input = { left:false, right:false, up:false, down:false, light:false, heavy:false, sp1:false, sp2:false, ultimate:false, block:false };
  }

  reset() {
    Object.keys(this.input).forEach(k => this.input[k] = false);
    this.actionTimer = 0;
  }

  think() {
    const f = this.fighter;
    const o = this.opponent;

    // Clear input each frame
    Object.keys(this.input).forEach(k => this.input[k] = false);

    if (f.state === 'dead' || f.hitstun > 0) return this.input;

    this.reactionTimer++;
    if (this.reactionTimer < this.reactionDelay) return this.input;

    const dist = Math.abs(f.cx - o.cx);
    const facingOpp = (o.cx > f.cx) === f.facingRight;

    // Face the opponent
    if (o.cx > f.cx && !f.facingRight) this.input.right = true;
    if (o.cx < f.cx && f.facingRight)  this.input.left = true;

    // HP-based aggression
    const hpRatio = f.hp / f.maxHP;
    const oppHpRatio = o.hp / o.maxHP;

    // Dodge if opponent is attacking
    if (o.state === 'attack' || o.state === 'special') {
      if (Math.random() < this.difficulty * 0.5) {
        if (dist < 150) {
          if (Math.random() < 0.4) this.input.block = true;
          else if (Math.random() < 0.5) this.input.up = true;
          else {
            this.input[f.facingRight ? 'left' : 'right'] = true;
          }
          return this.input;
        }
      }
    }

    // Use ultimate if ki is full and HP is low or opponent HP is low
    if (f.ki >= 95 && (hpRatio < 0.3 || oppHpRatio < 0.3) && Math.random() < 0.08 * this.difficulty) {
      this.input.ultimate = true;
      return this.input;
    }

    // Use special attacks
    if (f.ki >= 20 && Math.random() < 0.04 * this.difficulty) {
      if (dist > 200 && Math.random() < 0.6) this.input.sp1 = true;
      else if (dist < 150) this.input.sp2 = true;
    }

    // Healing (Zurak)
    if (f.charKey === 'zurak' && hpRatio < 0.4 && f.ki >= 20 && Math.random() < 0.05) {
      this.input.sp2 = true;
      return this.input;
    }

    // Approach and attack
    if (dist > 300) {
      this.input[f.facingRight ? 'right' : 'left'] = true;
      if (Math.random() < 0.03 * this.difficulty && f.ki >= 20) this.input.sp1 = true;
    } else if (dist > 100) {
      this.input[f.facingRight ? 'right' : 'left'] = true;
      if (Math.random() < 0.02) this.input.up = true;
    } else {
      // In range — attack
      if (Math.random() < 0.08 * this.difficulty) {
        if (Math.random() < 0.6) this.input.light = true;
        else this.input.heavy = true;
      }
    }

    // Occasional jump
    if (Math.random() < 0.005 && f.onGround) this.input.up = true;

    // Reset reaction delay
    this.reactionTimer = 0;
    this.reactionDelay = Math.floor(6 + (1 - this.difficulty) * 15);

    return this.input;
  }
}

// ── BACKGROUND RENDERER ──────────────────────────────────────────
function drawBackground(ctx, cW, cH, t) {
  // Sky gradient
  const skyGrad = ctx.createLinearGradient(0, 0, 0, cH);
  skyGrad.addColorStop(0, '#0a0020');
  skyGrad.addColorStop(0.5, '#0d0535');
  skyGrad.addColorStop(1, '#1a0a40');
  ctx.fillStyle = skyGrad;
  ctx.fillRect(0, 0, cW, cH);

  // Stars
  const starSeed = 42;
  for (let i = 0; i < 80; i++) {
    const sx = ((starSeed * (i * 7919 + 1)) % cW);
    const sy = ((starSeed * (i * 6271 + 3)) % (cH * 0.6));
    const pulse = Math.sin(t * 0.05 + i) * 0.3 + 0.7;
    ctx.globalAlpha = pulse * 0.8;
    ctx.fillStyle = '#fff';
    ctx.fillRect(sx, sy, 1.5, 1.5);
  }
  ctx.globalAlpha = 1;

  // Distant mountains
  ctx.fillStyle = '#160830';
  ctx.beginPath();
  ctx.moveTo(0, cH * 0.65);
  for (let x = 0; x <= cW; x += 60) {
    const h = Math.sin(x * 0.015) * 50 + Math.sin(x * 0.008) * 80 + cH * 0.5;
    ctx.lineTo(x, h);
  }
  ctx.lineTo(cW, cH); ctx.lineTo(0, cH);
  ctx.fill();

  // Mid mountains
  ctx.fillStyle = '#1f0a40';
  ctx.beginPath();
  ctx.moveTo(0, cH * 0.75);
  for (let x = 0; x <= cW; x += 40) {
    const h = Math.sin(x * 0.02 + 1) * 40 + Math.cos(x * 0.012) * 50 + cH * 0.6;
    ctx.lineTo(x, h);
  }
  ctx.lineTo(cW, cH); ctx.lineTo(0, cH);
  ctx.fill();

  // Platform glow
  const groundY = cH * 0.82;
  const platGrad = ctx.createLinearGradient(0, groundY - 10, 0, groundY + 20);
  platGrad.addColorStop(0, 'rgba(100,0,200,0.6)');
  platGrad.addColorStop(1, 'rgba(50,0,100,0)');
  ctx.fillStyle = platGrad;
  ctx.fillRect(0, groundY - 10, cW, 30);

  // Ground line
  ctx.strokeStyle = 'rgba(150,0,255,0.8)';
  ctx.lineWidth = 2;
  ctx.shadowBlur = 15;
  ctx.shadowColor = '#8b00ff';
  ctx.beginPath();
  ctx.moveTo(0, groundY); ctx.lineTo(cW, groundY);
  ctx.stroke();
  ctx.shadowBlur = 0;

  // Ground
  const groundGrad = ctx.createLinearGradient(0, groundY, 0, cH);
  groundGrad.addColorStop(0, '#1a0035');
  groundGrad.addColorStop(1, '#0a0015');
  ctx.fillStyle = groundGrad;
  ctx.fillRect(0, groundY, cW, cH - groundY);

  // Grid on ground
  ctx.strokeStyle = 'rgba(100,0,200,0.15)';
  ctx.lineWidth = 1;
  ctx.shadowBlur = 0;
  for (let x = 0; x < cW; x += 60) {
    ctx.beginPath(); ctx.moveTo(x, groundY); ctx.lineTo(x, cH); ctx.stroke();
  }
  for (let y = groundY; y < cH; y += 30) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(cW, y); ctx.stroke();
  }
}

// ── MAIN GAME CLASS ──────────────────────────────────────────────
class DragonFuryGame {
  constructor(p1CharKey, p2CharKey, mode='ai') {
    this.p1CharKey = p1CharKey;
    this.p2CharKey = p2CharKey;
    this.mode = mode; // 'ai' | '2p' | 'online'
    this.onlineMode = false;
    this.myIndex = 0; // which player this client controls in online mode

    this.canvas = document.getElementById('gameCanvas');
    this.ctx = this.canvas.getContext('2d');

    this.running = false;
    this.animId = null;

    this.frame = 0;
    this.phase = 'starting'; // starting|fighting|round_end|game_over
    this.phaseTimer = 0;

    this.round = 1;
    this.maxRounds = 3;
    this.roundTime = 99;
    this.timeLeft = this.roundTime;
    this.timeAccum = 0;

    this.p1Wins = 0;
    this.p2Wins = 0;

    this.particles = new ParticleSystem();
    this.comboDisplays = [];

    this.keys = {};
    this._onKey = (e, down) => {
      this.keys[e.code] = down;
      if (down) AudioEngine.resume();
      e.preventDefault();
    };

    this._resize();
    this._bindEvents();
    this._setupRound();
  }

  _resize() {
    const container = document.getElementById('canvas-container');
    this.canvas.width = container.clientWidth || window.innerWidth;
    this.canvas.height = container.clientHeight || window.innerHeight;
    this.cW = this.canvas.width;
    this.cH = this.canvas.height;
    this.groundY = this.cH * 0.82;
  }

  _bindEvents() {
    this._keyDown = (e) => this._onKey(e, true);
    this._keyUp   = (e) => this._onKey(e, false);
    window.addEventListener('keydown', this._keyDown);
    window.addEventListener('keyup',   this._keyUp);
    this._resizeFn = () => this._resize();
    window.addEventListener('resize', this._resizeFn);
  }

  _unbindEvents() {
    window.removeEventListener('keydown', this._keyDown);
    window.removeEventListener('keyup',   this._keyUp);
    window.removeEventListener('resize',  this._resizeFn);
  }

  _setupRound() {
    const margin = this.cW * 0.25;
    this.p1 = new Fighter(this.p1CharKey, margin, true, 1);
    this.p2 = new Fighter(this.p2CharKey, this.cW - margin - 60, false, 2);
    this.p1.y = this.groundY - this.p1.h;
    this.p2.y = this.groundY - this.p2.h;

    if (this.mode === 'ai') {
      this.ai = new AIController(this.p2, this.p1);
    } else {
      this.ai = null;
    }

    this.timeLeft = this.roundTime;
    this.timeAccum = 0;
    this.particles.particles = [];
    this.comboDisplays = [];

    this.phase = 'starting';
    this.phaseTimer = 90;
    this._announce(`ROUND ${this.round}`);
    setTimeout(() => this._announce('LUTAR!'), 1200);
    setTimeout(() => AudioEngine.play('round_start'), 500);
  }

  _announce(text) {
    const el = document.getElementById('round-announce');
    el.textContent = text;
    el.classList.remove('show');
    void el.offsetWidth;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 1600);
  }

  _buildInput(keys, map) {
    const input = {};
    Object.entries(map).forEach(([action, codes]) => {
      input[action] = codes.some(c => keys[c]);
    });
    return input;
  }

  _getP1Input() {
    return this._buildInput(this.keys, {
      left:    ['KeyA'],
      right:   ['KeyD'],
      up:      ['KeyW'],
      down:    ['KeyS'],
      light:   ['KeyF'],
      heavy:   ['KeyG'],
      sp1:     ['KeyH'],
      sp2:     ['KeyJ'],
      ultimate:['KeyK'],
      block:   ['KeyL'],
    });
  }

  _getP2Input() {
    return this._buildInput(this.keys, {
      left:    ['ArrowLeft'],
      right:   ['ArrowRight'],
      up:      ['ArrowUp'],
      down:    ['ArrowDown'],
      light:   ['Digit1','Numpad1'],
      heavy:   ['Digit2','Numpad2'],
      sp1:     ['Digit3','Numpad3'],
      sp2:     ['Digit4','Numpad4'],
      ultimate:['Digit5','Numpad5'],
      block:   ['Digit6','Numpad6'],
    });
  }

  _checkCollisions() {
    // Projectiles hitting fighters
    [this.p1, this.p2].forEach((attacker, i) => {
      const defender = i === 0 ? this.p2 : this.p1;
      attacker.projectiles = attacker.projectiles.filter(proj => {
        const hit = proj.x > defender.x && proj.x < defender.x + defender.w &&
                    proj.y > defender.y && proj.y < defender.y + defender.h;
        if (hit) {
          defender.receiveHit({ damage: proj.damage, knockback: 5, kiGain: 10, startup: 5 }, attacker, this.particles);
          this.particles.emit(proj.x, proj.y, 'blast', 15);
          this._addComboDisplay(attacker, proj.damage);
          return false;
        }
        return true;
      });
    });

    // Melee hitboxes
    [this.p1, this.p2].forEach((attacker, i) => {
      const defender = i === 0 ? this.p2 : this.p1;
      const hb = attacker.getHitbox();
      if (!hb || (attacker.attackData && attacker.attackData.hitLanded)) return;

      const overlap = hb.x < defender.x + defender.w && hb.x + hb.w > defender.x &&
                      hb.y < defender.y + defender.h && hb.y + hb.h > defender.y;
      if (overlap) {
        const hit = defender.receiveHit(attacker.attackData, attacker, this.particles);
        if (hit) {
          attacker.attackData.hitLanded = true;
          this._addComboDisplay(attacker, attacker.attackData.damage);
        }
      }
    });
  }

  _addComboDisplay(fighter, damage) {
    const isP1 = fighter === this.p1;
    this.comboDisplays.push({
      x: isP1 ? this.cW * 0.25 : this.cW * 0.6,
      y: this.cH * 0.4,
      damage,
      combo: fighter.combo,
      life: 1.2,
      player: isP1 ? 1 : 2,
    });
  }

  _updateHUD() {
    document.getElementById('hp-bar-p1').style.width = `${(this.p1.hp / this.p1.maxHP) * 100}%`;
    document.getElementById('hp-bar-p2').style.width = `${(this.p2.hp / this.p2.maxHP) * 100}%`;
    document.getElementById('ki-bar-p1').style.width  = `${(this.p1.ki / this.p1.maxKi) * 100}%`;
    document.getElementById('ki-bar-p2').style.width  = `${(this.p2.ki / this.p2.maxKi) * 100}%`;

    const t = document.getElementById('timer-display');
    t.textContent = Math.ceil(this.timeLeft);
    t.className = 'timer-display' + (this.timeLeft < 15 ? ' urgent' : '');

    document.getElementById('round-label').textContent = `ROUND ${this.round}`;

    // Round pips
    ['p1','p2'].forEach((p, i) => {
      const wins = i === 0 ? this.p1Wins : this.p2Wins;
      const el = document.getElementById(`rounds-${p}`);
      el.innerHTML = '';
      for (let r = 0; r < Math.ceil(this.maxRounds / 2); r++) {
        const pip = document.createElement('div');
        pip.className = 'round-pip' + (r < wins ? ` won ${p}` : '');
        el.appendChild(pip);
      }
    });

    document.getElementById('hud-p1-name').textContent = this.p1.def.name;
    document.getElementById('hud-p2-name').textContent = this.p2.def.name;
  }

  handleOpponentDisconnect() {
    this._announce('OPONENTE SAIU');
    setTimeout(() => {
      this.stop();
      showOnlineGameOver(this.myIndex);
    }, 2000);
  }

  _endRound(winner) {
    if (this.phase === 'round_end' || this.phase === 'game_over') return;
    this.phase = 'round_end';
    this.phaseTimer = 120;

    if (winner === 'p1' || winner === 'timeout_p1') {
      this.p1Wins++;
      this._announce(winner === 'timeout' ? 'TEMPO!' : 'K.O.!');
    } else {
      this.p2Wins++;
      this._announce(winner === 'timeout' ? 'TEMPO!' : 'K.O.!');
    }
    AudioEngine.play('ko');

    const winsNeeded = Math.ceil(this.maxRounds / 2);
    if (this.p1Wins >= winsNeeded || this.p2Wins >= winsNeeded) {
      this.phase = 'game_over';
      const winnerIdx = this.p1Wins >= winsNeeded ? 0 : 1;
      if (this.onlineMode) {
        Online.emitGameEvent({ type: 'game_over', winnerIndex: winnerIdx });
        setTimeout(() => { this.stop(); showOnlineGameOver(winnerIdx); }, 2000);
      } else {
        setTimeout(() => this._showGameOver(), 2000);
      }
    } else {
      this.round++;
      setTimeout(() => this._setupRound(), 2500);
    }
  }

  _showGameOver() {
    this.stop();
    const winner = this.p1Wins > this.p2Wins ? this.p1 : this.p2;
    const winnerName = document.getElementById('winner-name-display');
    winnerName.textContent = winner.def.name;
    winnerName.style.color = winner.def.color;
    winnerName.style.textShadow = `0 0 30px ${winner.def.color}`;

    // Draw winner on canvas
    const wc = document.getElementById('winner-canvas');
    const wctx = wc.getContext('2d');
    wctx.clearRect(0, 0, 200, 250);
    winner.x = 70; winner.y = 140; winner.facingRight = true;
    winner.state = 'idle'; winner.animFrame = 0;
    winner.draw(wctx, 200, 250);

    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('game-over-screen').classList.add('active');
  }

  _update() {
    this.frame++;

    if (this.phase === 'starting') {
      this.phaseTimer--;
      if (this.phaseTimer <= 0) this.phase = 'fighting';
      return;
    }

    if (this.phase === 'round_end' || this.phase === 'game_over') return;

    // Timer
    this.timeAccum++;
    if (this.timeAccum >= 60) {
      this.timeAccum = 0;
      this.timeLeft--;
      if (this.timeLeft <= 0) {
        // Judge by HP
        if (this.p1.hp > this.p2.hp) this._endRound('p1');
        else this._endRound('p2');
        return;
      }
    }

    // Inputs
    let p1In, p2In;
    if (this.onlineMode) {
      // My input from keyboard; opponent input from network buffer
      const myInput = this.myIndex === 0 ? this._getP1Input() : this._getP2Input();
      Online.sendInput(this.frame, myInput);
      const oppInput = Online.getOppInput(this.frame);
      p1In = this.myIndex === 0 ? myInput : oppInput;
      p2In = this.myIndex === 0 ? oppInput : myInput;
    } else {
      p1In = this._getP1Input();
      p2In = this.mode === 'ai' ? this.ai.think() : this._getP2Input();
    }

    // Single-frame input (edge detection via consumed flags)
    this.p1.applyInput(p1In, this.groundY, this.cW);
    this.p2.applyInput(p2In, this.groundY, this.cW);

    // Keep fighters facing each other
    if (!this.p1.attackData && this.p1.state !== 'attack' && this.p1.state !== 'special' && this.p1.state !== 'block') {
      this.p1.facingRight = this.p2.cx > this.p1.cx;
    }
    if (!this.p2.attackData && this.p2.state !== 'attack' && this.p2.state !== 'special' && this.p2.state !== 'block') {
      this.p2.facingRight = this.p1.cx > this.p2.cx;
    }

    // Update fighters
    this.p1.update(this.groundY, this.cW, this.particles);
    this.p2.update(this.groundY, this.cW, this.particles);

    // Push apart if overlapping
    const overlap = this.p1.x + this.p1.w > this.p2.x && this.p2.x + this.p2.w > this.p1.x;
    if (overlap) {
      const push = 2;
      if (this.p1.cx < this.p2.cx) { this.p1.x -= push; this.p2.x += push; }
      else { this.p1.x += push; this.p2.x -= push; }
    }

    this._checkCollisions();
    this.particles.update();

    // Combo displays
    this.comboDisplays = this.comboDisplays.filter(c => { c.life -= 0.025; return c.life > 0; });

    // Check KO
    if (this.p1.hp <= 0) {
      this.p1.state = 'dead';
      this._endRound('p2');
    } else if (this.p2.hp <= 0) {
      this.p2.state = 'dead';
      this._endRound('p1');
    }

    this._updateHUD();
  }

  _draw() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.cW, this.cH);

    drawBackground(ctx, this.cW, this.cH, this.frame);

    this.particles.draw(ctx);

    this.p1.draw(ctx, this.cW, this.cH);
    this.p2.draw(ctx, this.cW, this.cH);

    // Combo/damage displays
    this.comboDisplays.forEach(c => {
      ctx.save();
      ctx.globalAlpha = Math.min(1, c.life * 2);
      const scale = 1 + (1 - c.life) * 0.3;
      ctx.translate(c.x, c.y - (1 - c.life) * 60);
      ctx.scale(scale, scale);

      ctx.font = `bold ${c.combo > 2 ? 24 : 18}px Orbitron`;
      ctx.textAlign = 'center';

      const col = c.player === 1 ? '#00cfff' : '#ff4444';
      ctx.fillStyle = col;
      ctx.shadowBlur = 10;
      ctx.shadowColor = col;

      if (c.combo > 2) {
        ctx.fillStyle = '#ffd700';
        ctx.shadowColor = '#ffd700';
        ctx.font = `bold 20px Orbitron`;
        ctx.fillText(`${c.combo} HIT!`, 0, -24);
      }
      ctx.fillStyle = col;
      ctx.shadowColor = col;
      ctx.font = `bold 18px Orbitron`;
      ctx.fillText(`-${c.damage}`, 0, 0);
      ctx.restore();
    });

    // Draw hitboxes (debug — comment out in prod)
    // this._drawHitboxes(ctx);
  }

  _drawHitboxes(ctx) {
    [this.p1, this.p2].forEach(f => {
      const hb = f.getHitbox();
      if (hb) {
        ctx.strokeStyle = 'lime';
        ctx.lineWidth = 2;
        ctx.strokeRect(hb.x, hb.y, hb.w, hb.h);
      }
      ctx.strokeStyle = 'red';
      ctx.lineWidth = 1;
      ctx.strokeRect(f.x, f.y, f.w, f.h);
    });
  }

  _loop() {
    this._update();
    this._draw();
    if (this.running) {
      this.animId = requestAnimationFrame(() => this._loop());
    }
  }

  start() {
    AudioEngine.init();
    this.running = true;
    this._loop();
  }

  stop() {
    this.running = false;
    if (this.animId) cancelAnimationFrame(this.animId);
    this._unbindEvents();
  }
}

// ── CHARACTER SELECT ─────────────────────────────────────────────
const gameState = {
  p1Char: null,
  p2Char: null,
  mode: 'ai',
};

function initCharSelect() {
  const grid = document.getElementById('char-grid');
  grid.innerHTML = '';

  Object.entries(CHARACTERS).forEach(([key, def]) => {
    const card = document.createElement('div');
    card.className = 'char-card';
    card.dataset.key = key;

    const c = document.createElement('canvas');
    c.width = card.offsetWidth || 110;
    c.height = card.offsetHeight || 130;
    card.appendChild(c);

    const nameEl = document.createElement('div');
    nameEl.className = 'char-card-name';
    nameEl.textContent = def.name;
    card.appendChild(nameEl);

    card.addEventListener('click', (e) => {
      if (e.shiftKey || gameState.p1Char) {
        if (!e.shiftKey && gameState.p1Char) {
          // second click = p2
          selectChar(key, 2);
        } else {
          selectChar(key, 2);
        }
      } else {
        selectChar(key, 1);
      }
      AudioEngine.init();
      AudioEngine.play('menu_sel');
    });

    grid.appendChild(card);

    // Draw mini character
    setTimeout(() => {
      c.width = card.clientWidth;
      c.height = card.clientHeight;
      const ctx = c.getContext('2d');
      const f = new Fighter(key, 0, true, 0);
      f.x = card.clientWidth * 0.1;
      f.y = card.clientHeight - f.h - 5;
      f.draw(ctx, card.clientWidth, card.clientHeight);
    }, 100);
  });

  // Auto-select defaults
  gameState.p1Char = null;
  gameState.p2Char = null;
  updateSelectUI();
}

function selectChar(key, player) {
  if (player === 1) {
    gameState.p1Char = key;
    document.getElementById('p1-select-label').textContent = `P1 — ${CHARACTERS[key].name}`;
  } else {
    gameState.p2Char = key;
    document.getElementById('p2-select-label').textContent = `${gameState.mode === 'ai' ? 'CPU' : 'P2'} — ${CHARACTERS[key].name}`;
  }
  updateSelectUI();
}

function updateSelectUI() {
  // Update card highlights
  document.querySelectorAll('.char-card').forEach(card => {
    card.classList.remove('selected-p1', 'selected-p2');
    if (card.dataset.key === gameState.p1Char) card.classList.add('selected-p1');
    if (card.dataset.key === gameState.p2Char) card.classList.add('selected-p2');
  });

  // Update previews
  updatePreview('p1', gameState.p1Char);
  updatePreview('p2', gameState.p2Char);

  // Enable fight button
  const btn = document.getElementById('fight-btn');
  btn.disabled = !(gameState.p1Char && gameState.p2Char);

  // Auto-select CPU character
  if (gameState.mode === 'ai' && gameState.p1Char && !gameState.p2Char) {
    const keys = Object.keys(CHARACTERS);
    const aiKey = keys[Math.floor(Math.random() * keys.length)];
    gameState.p2Char = aiKey;
    document.getElementById('p2-select-label').textContent = `CPU — ${CHARACTERS[aiKey].name}`;
    updateSelectUI();
  }
}

function updatePreview(player, charKey) {
  const canvas = document.getElementById(`${player}-preview-canvas`);
  const nameEl = document.getElementById(`${player}-preview-name`);
  const statsEl = document.getElementById(`${player}-stats`);

  if (!charKey) {
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    nameEl.textContent = '???';
    statsEl.innerHTML = '';
    return;
  }

  const def = CHARACTERS[charKey];
  nameEl.textContent = def.name;
  nameEl.style.color = def.color;

  // Draw preview
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const f = new Fighter(charKey, 0, player === 'p1', 0);
  f.x = canvas.width / 2 - f.w / 2;
  f.y = canvas.height - f.h - 10;
  f.state = 'idle';
  f.draw(ctx, canvas.width, canvas.height);

  // Stats
  statsEl.innerHTML = '';
  const statColors = { power: '#ff4444', speed: '#00cfff', defense: '#00ff88', ki: '#ffd700' };
  const statNames = { power: 'FORÇA', speed: 'VEL.', defense: 'DEF.', ki: 'KI' };
  Object.entries(def.stats).forEach(([stat, val]) => {
    const row = document.createElement('div');
    row.className = 'stat-row';
    row.innerHTML = `
      <div class="stat-label">${statNames[stat]}</div>
      <div class="stat-bar"><div class="stat-fill" style="width:${val}%;background:${statColors[stat]}"></div></div>
    `;
    statsEl.appendChild(row);
  });
}

function setMode(mode) {
  gameState.mode = mode;
  document.getElementById('mode-ai').className = 'mode-btn' + (mode === 'ai' ? ' active' : '');
  document.getElementById('mode-2p').className = 'mode-btn' + (mode === '2p' ? ' active' : '');

  if (mode === '2p') {
    gameState.p2Char = null;
    document.getElementById('p2-select-label').textContent = 'P2 — SELECIONE';
    document.getElementById('select-hint').textContent = 'P1: clique · P2: shift+clique';
    document.getElementById('fight-btn').disabled = true;
    updateSelectUI();
  } else {
    gameState.p2Char = null;
    if (gameState.p1Char) updateSelectUI();
    document.getElementById('select-hint').textContent = 'P1: clique para selecionar · P2: shift+clique';
  }
  AudioEngine.init();
  AudioEngine.play('menu_sel');
}

// Auto-animate character select cards
let csAnimId;
function animateSelectCards() {
  if (!document.getElementById('char-select-screen').classList.contains('active')) {
    cancelAnimationFrame(csAnimId);
    return;
  }
  document.querySelectorAll('.char-card').forEach(card => {
    const c = card.querySelector('canvas');
    if (!c || !card.dataset.key) return;
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, c.width, c.height);
    const f = new Fighter(card.dataset.key, 0, true, 0);
    f.x = c.width * 0.1;
    f.y = c.height - f.h - 5;
    f.animFrame = Math.floor(Date.now() / 100);
    f.draw(ctx, c.width, c.height);
  });
  ['p1','p2'].forEach(p => {
    const key = p === 'p1' ? gameState.p1Char : gameState.p2Char;
    if (!key) return;
    const c = document.getElementById(`${p}-preview-canvas`);
    if (!c) return;
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, c.width, c.height);
    const f = new Fighter(key, 0, p === 'p1', 0);
    f.x = c.width / 2 - f.w / 2;
    f.y = c.height - f.h - 10;
    f.animFrame = Math.floor(Date.now() / 100);
    f.draw(ctx, c.width, c.height);
  });
  csAnimId = requestAnimationFrame(animateSelectCards);
}

// Observe screen changes to start/stop card anim
const origShowCharSelect = window.showCharSelect;
window.showCharSelect = function() {
  setScreen('char-select-screen');
  if (window.game) window.game.stop();
  initCharSelect();
  cancelAnimationFrame(csAnimId);
  animateSelectCards();
};

function setScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}
