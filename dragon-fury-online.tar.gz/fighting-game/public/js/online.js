'use strict';
// ═══════════════════════════════════════════════════════════════
//  DRAGON FURY — Online Networking Layer
//  Input-relay architecture: each client runs the full sim,
//  sends its own inputs to the server, receives opponent inputs.
//  Deterministic physics keeps both sides in sync.
// ═══════════════════════════════════════════════════════════════

const Online = (() => {
  let socket = null;
  let connected = false;
  let playerIndex = -1;   // 0 = P1, 1 = P2
  let roomCode = null;
  let myChar = null;
  let oppChar = null;
  let pingStart = 0;
  let currentPing = 0;
  let pingInterval = null;

  // Input buffer: { frame: { left, right, up, down, light, heavy, sp1, sp2, ultimate, block } }
  const oppInputBuffer = {};

  function init() {
    if (socket) return;
    socket = io({ transports: ['websocket', 'polling'] });

    socket.on('connect', () => {
      connected = true;
      console.log('[Online] connected', socket.id);
      updateStatusBar(true);
      startPing();
    });

    socket.on('disconnect', () => {
      connected = false;
      updateStatusBar(false);
      stopPing();
    });

    socket.on('pong_check', (ts) => {
      currentPing = Date.now() - ts;
      const el = document.getElementById('ping-display');
      if (el) el.textContent = `PING: ${currentPing}ms`;
    });

    // ── Room events ──
    socket.on('room_created', ({ code, playerIndex: idx }) => {
      roomCode = code;
      playerIndex = idx;
      showLobby(idx);
      document.getElementById('share-code').textContent = code;
      document.getElementById('copy-code-row').style.display = 'flex';
      document.getElementById('room-code-display').textContent = `SALA: ${code}`;
    });

    socket.on('room_joined', ({ code, playerIndex: idx, p1Char }) => {
      roomCode = code;
      playerIndex = idx;
      oppChar = p1Char;
      showLobby(idx);
      document.getElementById('lobby-p2-name').textContent = 'VOCÊ';
      document.getElementById('lobby-p1-name').textContent = 'OPONENTE';
      document.getElementById('lobby-status').textContent = 'Conectado! Aguardando início...';
      if (p1Char) drawLobbyChar('p1', p1Char);
    });

    socket.on('opponent_joined', ({ charKey }) => {
      oppChar = charKey;
      document.getElementById('lobby-status').innerHTML = `Oponente encontrado! <span class="lobby-dot"></span>`;
      document.getElementById('lobby-p2-name').textContent = 'OPONENTE';
      if (charKey) drawLobbyChar('p2', charKey);
    });

    socket.on('opponent_char', ({ charKey }) => {
      oppChar = charKey;
      const side = playerIndex === 0 ? 'p2' : 'p1';
      drawLobbyChar(side, charKey);
    });

    socket.on('fight_start', ({ chars }) => {
      // chars[0] = P1 char, chars[1] = P2 char
      const myCharKey  = chars[playerIndex];
      const oppCharKey = chars[1 - playerIndex];
      myChar  = myCharKey;
      oppChar = oppCharKey;
      launchOnlineFight(myCharKey, oppCharKey, playerIndex);
    });

    socket.on('opponent_input', ({ frame, input }) => {
      oppInputBuffer[frame] = input;
    });

    socket.on('opponent_disconnected', ({ playerIndex: idx }) => {
      if (window.game && window.game.onlineMode) {
        window.game.handleOpponentDisconnect();
      }
      showNotification('Oponente desconectado');
    });

    socket.on('rematch_start', ({ chars }) => {
      const myCharKey  = chars[playerIndex];
      const oppCharKey = chars[1 - playerIndex];
      launchOnlineFight(myCharKey, oppCharKey, playerIndex);
    });

    socket.on('rematch_requested', () => {
      document.getElementById('rematch-status').innerHTML = 'Oponente quer revanche! <span class="lobby-dot"></span>';
    });

    socket.on('error', ({ msg }) => {
      showNotification(msg, '#ff4444');
    });

    socket.on('spectating', ({ chars, state }) => {
      showNotification('Entrando como espectador');
    });
  }

  function startPing() {
    pingInterval = setInterval(() => {
      if (socket && connected) {
        pingStart = Date.now();
        socket.emit('ping_check', pingStart);
      }
    }, 2000);
  }

  function stopPing() {
    if (pingInterval) clearInterval(pingInterval);
  }

  function sendInput(frame, input) {
    if (!socket || !connected || !roomCode) return;
    socket.emit('input', { frame, input });
  }

  function getOppInput(frame) {
    // Return buffered opponent input for this frame, or last known
    if (oppInputBuffer[frame]) {
      const inp = oppInputBuffer[frame];
      delete oppInputBuffer[frame];
      return inp;
    }
    // Dead-reckoning: return all-off if nothing buffered (causes small desync but recoverable)
    return { left:false, right:false, up:false, down:false, light:false, heavy:false, sp1:false, sp2:false, ultimate:false, block:false };
  }

  function createRoom(charKey) {
    if (!connected) { showNotification('Sem conexão'); return; }
    myChar = charKey;
    socket.emit('create_room', { charKey });
  }

  function joinRoom(code, charKey) {
    if (!connected) { showNotification('Sem conexão'); return; }
    myChar = charKey;
    socket.emit('join_room', { code, charKey });
  }

  function selectChar(charKey) {
    myChar = charKey;
    if (socket && connected) socket.emit('char_selected', { charKey });
  }

  function leaveRoom() {
    roomCode = null; playerIndex = -1; myChar = null; oppChar = null;
    Object.keys(oppInputBuffer).forEach(k => delete oppInputBuffer[k]);
    if (socket) socket.disconnect();
    socket = null;
    connected = false;
  }

  function emitGameEvent(data) {
    if (socket && connected) socket.emit('game_event', data);
  }

  function requestRematch() {
    if (socket && connected) socket.emit('rematch');
  }

  function updateStatusBar(isConn) {
    let bar = document.getElementById('online-status-bar');
    if (!bar) {
      bar = document.createElement('div');
      bar.id = 'online-status-bar';
      bar.className = 'online-status-bar';
      document.body.appendChild(bar);
    }
    bar.textContent = isConn ? '● ONLINE' : '○ OFFLINE';
    bar.className = 'online-status-bar' + (isConn ? ' connected' : '');
  }

  function showNotification(msg, color='#ffd700') {
    const n = document.createElement('div');
    n.style.cssText = `
      position:fixed;top:20px;left:50%;transform:translateX(-50%);
      font-family:Orbitron,sans-serif;font-size:0.75rem;letter-spacing:0.15em;
      color:${color};background:rgba(0,0,0,0.9);border:1px solid ${color};
      padding:0.6em 1.5em;z-index:200;pointer-events:none;
      animation:notify-anim 2.5s ease forwards;
    `;
    n.textContent = msg;
    document.body.appendChild(n);
    const style = document.createElement('style');
    style.textContent = '@keyframes notify-anim{0%{opacity:0;top:30px}15%{opacity:1;top:20px}75%{opacity:1;top:20px}100%{opacity:0;top:10px}}';
    document.head.appendChild(style);
    setTimeout(() => { n.remove(); style.remove(); }, 2600);
  }

  function drawLobbyChar(side, charKey) {
    const c = document.getElementById(`lobby-${side}-canvas`);
    if (!c || !charKey) return;
    const ctx = c.getContext('2d');
    ctx.clearRect(0, 0, c.width, c.height);
    const f = new Fighter(charKey, 0, side === 'p1', 0);
    f.x = c.width / 2 - f.w / 2;
    f.y = c.height - f.h - 5;
    f.animFrame = Math.floor(Date.now() / 100);
    f.draw(ctx, c.width, c.height);
    const name = CHARACTERS[charKey]?.name || charKey;
    const side_id = side === 'p1' ? 'lobby-p1-name' : 'lobby-p2-name';
    const el = document.getElementById(side_id);
    if (el && (el.textContent === '???' || el.textContent === 'OPONENTE' || el.textContent === 'VOCÊ')) {
      // keep player label, add char name
    }
    // animate
    requestAnimationFrame(() => drawLobbyChar(side, charKey));
  }

  return { init, sendInput, getOppInput, createRoom, joinRoom, selectChar, leaveRoom, emitGameEvent, requestRematch, get playerIndex() { return playerIndex; }, get connected() { return connected; }, get roomCode() { return roomCode; } };
})();

// ── LAUNCH ONLINE FIGHT ──────────────────────────────────────────
function launchOnlineFight(myCharKey, oppCharKey, myIndex) {
  // P1 always faces right; we just swap which char belongs to which side
  const p1Key = myIndex === 0 ? myCharKey : oppCharKey;
  const p2Key = myIndex === 0 ? oppCharKey : myCharKey;

  setScreen('game-screen');
  window.game = new DragonFuryGame(p1Key, p2Key, 'online');
  window.game.onlineMode = true;
  window.game.myIndex = myIndex;
  window.game.start();

  document.getElementById('online-screen').classList.remove('active');
}

// ── ONLINE LOBBY UI FUNCTIONS ────────────────────────────────────
let onlineCharSelection = null;

function showOnline() {
  Online.init();
  setScreen('online-screen');
  document.getElementById('online-char-step').style.display = 'flex';
  document.getElementById('online-lobby-step').style.display = 'none';
  document.getElementById('online-rematch-step').style.display = 'none';
  document.getElementById('join-box').style.display = 'none';
  onlineCharSelection = null;
  buildOnlineCharGrid();
}

function buildOnlineCharGrid() {
  const grid = document.getElementById('online-char-grid');
  grid.innerHTML = '';
  Object.entries(CHARACTERS).forEach(([key, def]) => {
    const card = document.createElement('div');
    card.className = 'char-card';
    card.dataset.key = key;

    const c = document.createElement('canvas');
    c.width = 90; c.height = 110;
    card.appendChild(c);

    const nameEl = document.createElement('div');
    nameEl.className = 'char-card-name';
    nameEl.textContent = def.name;
    card.appendChild(nameEl);

    card.addEventListener('click', () => {
      document.querySelectorAll('#online-char-grid .char-card').forEach(cc => cc.classList.remove('selected-online'));
      card.classList.add('selected-online');
      onlineCharSelection = key;
      document.getElementById('online-selected-name').textContent = def.name;
      AudioEngine.init();
      AudioEngine.play('menu_sel');

      setTimeout(() => {
        const ctx = c.getContext('2d');
        ctx.clearRect(0, 0, 90, 110);
        const f = new Fighter(key, 0, true, 0);
        f.x = 10; f.y = 110 - f.h - 5;
        f.animFrame = Math.floor(Date.now()/100);
        f.draw(ctx, 90, 110);
      }, 50);
    });

    grid.appendChild(card);
    setTimeout(() => {
      const ctx = c.getContext('2d');
      ctx.clearRect(0, 0, 90, 110);
      const f = new Fighter(key, 0, true, 0);
      f.x = 10; f.y = 110 - f.h - 5;
      f.animFrame = 0;
      f.draw(ctx, 90, 110);
    }, 80);
  });
}

function showJoinBox() {
  const jb = document.getElementById('join-box');
  jb.style.display = jb.style.display === 'none' ? 'flex' : 'none';
}

function onlineCreateRoom() {
  if (!onlineCharSelection) { showOnlineError('Selecione um personagem'); return; }
  Online.createRoom(onlineCharSelection);
  // Show lobby immediately
  showLobby(0);
  document.getElementById('lobby-status').innerHTML = `Aguardando oponente... <span class="lobby-dot"></span>`;
  document.getElementById('copy-code-row').style.display = 'flex';
  drawLobbyChar('p1', onlineCharSelection);
}

function onlineJoinRoom() {
  if (!onlineCharSelection) { showOnlineError('Selecione um personagem'); return; }
  const code = document.getElementById('room-code-input').value.trim().toUpperCase();
  if (code.length < 6) { showOnlineError('Código inválido'); return; }
  Online.joinRoom(code, onlineCharSelection);
  document.getElementById('lobby-status').innerHTML = `Conectando... <span class="lobby-dot"></span>`;
  showLobby(1);
  drawLobbyChar('p2', onlineCharSelection);
}

function showLobby(myIdx) {
  document.getElementById('online-char-step').style.display = 'none';
  document.getElementById('online-lobby-step').style.display = 'flex';
  document.getElementById('online-rematch-step').style.display = 'none';

  if (myIdx === 0) {
    document.getElementById('lobby-p1-name').textContent = 'VOCÊ (P1)';
    document.getElementById('lobby-p2-name').textContent = '???';
  } else {
    document.getElementById('lobby-p1-name').textContent = 'OPONENTE (P1)';
    document.getElementById('lobby-p2-name').textContent = 'VOCÊ (P2)';
  }
}

function onlineLeaveRoom() {
  Online.leaveRoom();
  showTitle();
}

function copyRoomCode() {
  const code = document.getElementById('share-code').textContent;
  navigator.clipboard?.writeText(code).then(() => {
    document.getElementById('share-code').style.color = '#00ff88';
    setTimeout(() => { document.getElementById('share-code').style.color = '#cc44ff'; }, 1000);
  });
}

function showOnlineError(msg) {
  const el = document.getElementById('online-selected-name');
  el.textContent = msg;
  el.style.color = '#ff4444';
  setTimeout(() => { el.style.color = '#cc44ff'; el.textContent = onlineCharSelection ? CHARACTERS[onlineCharSelection].name : '???'; }, 2000);
}

function requestRematch() {
  Online.requestRematch();
  document.getElementById('rematch-status').innerHTML = 'Pedido enviado... <span class="lobby-dot"></span>';
}

function showOnlineGameOver(winnerIndex) {
  document.getElementById('online-screen').classList.add('active');
  document.getElementById('online-char-step').style.display = 'none';
  document.getElementById('online-lobby-step').style.display = 'none';
  document.getElementById('online-rematch-step').style.display = 'flex';
  const myIndex = Online.playerIndex;
  document.getElementById('rematch-status').textContent = winnerIndex === myIndex ? 'VITÓRIA!' : 'DERROTA...';
}
