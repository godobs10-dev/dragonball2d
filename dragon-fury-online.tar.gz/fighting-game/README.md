# Dragon Fury — 2D Fighter

Jogo de luta 2D completo. 4 personagens, IA, efeitos de partículas, áudio procedural.

## Deploy no Railway

1. Push para GitHub:
```bash
cd fighting-game
git init
git add .
git commit -m "Dragon Fury 2D Fighter"
git remote add origin https://github.com/SEU_USUARIO/dragon-fury.git
git push -u origin main
```

2. No Railway.app:
   - New Project → Deploy from GitHub repo
   - Selecione o repositório
   - Railway detecta Node.js automaticamente e usa `npm start`
   - Pronto — URL gerada em segundos

## Personagens

| Nome | Estilo | Especial |
|------|--------|---------|
| Kairu | Equilibrado | Feixe de Ki, Golpe Relâmpago |
| Vegara | Agressivo | Chuva de Ki, Investida Final |
| Zurak | Defensivo | Anel de Energia, Regenerar |
| Miroku | Velocidade | Golpe Fantasma, Rafaga de Sombras |

## Controles P1

| Ação | Tecla |
|------|-------|
| Mover | WASD |
| Ataque Leve | F |
| Ataque Forte | G |
| Especial 1 | H |
| Especial 2 | J |
| Ultimate | K |
| Bloquear | L |

## Controles P2

| Ação | Tecla |
|------|-------|
| Mover | Setas |
| Ataque Leve | 1 |
| Ataque Forte | 2 |
| Especial 1 | 3 |
| Especial 2 | 4 |
| Ultimate | 5 |
| Bloquear | 6 |

> Ultimate requer Ki 100% (barra amarela cheia)
